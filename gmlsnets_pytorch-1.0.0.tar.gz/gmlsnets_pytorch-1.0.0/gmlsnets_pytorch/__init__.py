# global initialization 
name="gmlsnets_pytorch"; # package name
__version__="1.0.0"; # package version

